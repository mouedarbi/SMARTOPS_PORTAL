import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Signature & Rapports",
            "url": "/app/signature_electronique_rapports_pdf/",
            "icon": "la-signature"
        }]

plugin_implementation = PlaceholderPlugin()

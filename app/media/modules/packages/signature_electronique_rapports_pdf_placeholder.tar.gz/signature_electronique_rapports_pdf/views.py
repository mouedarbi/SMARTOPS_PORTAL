from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'signature_electronique_rapports_pdf/index.html', {
        'page_title': 'Signature Électronique & Rapports PDF',
        'description': 'Signature électronique des bons d'intervention et rapports PDF.'
    })

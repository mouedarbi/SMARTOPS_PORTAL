import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Stock & Pièces",
            "url": "/app/stock_pieces_detachees/",
            "icon": "la-boxes"
        }]

plugin_implementation = PlaceholderPlugin()

from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'stock_pieces_detachees/index.html', {
        'page_title': 'Stock & Pièces Détachées',
        'description': 'Suivi de l'inventaire des pièces détachées et alertes.'
    })

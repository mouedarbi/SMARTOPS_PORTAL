import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Localisation des Sites",
            "url": "/app/localisation_des_sites/",
            "icon": "la-map-marked-alt"
        }]

plugin_implementation = PlaceholderPlugin()

from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'localisation_des_sites/index.html', {
        'page_title': 'Localisation des sites',
        'description': 'Cartographie interactive et géolocalisation des sites.'
    })

from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'hrm_absences_redistribution_de_charge/index.html', {
        'page_title': 'HRM - Absences & Redistribution de Charge',
        'description': 'Gestion des absences, congés et répartition de la charge.'
    })

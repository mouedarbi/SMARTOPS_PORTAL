import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Planning & RH",
            "url": "/app/hrm_absences_redistribution_de_charge/",
            "icon": "la-users-cog"
        }]

plugin_implementation = PlaceholderPlugin()

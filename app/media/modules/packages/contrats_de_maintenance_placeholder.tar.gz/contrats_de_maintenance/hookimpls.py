import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Contrats de Maintenance",
            "url": "/app/contrats_de_maintenance/",
            "icon": "la-file-contract"
        }]

plugin_implementation = PlaceholderPlugin()

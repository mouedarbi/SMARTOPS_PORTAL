from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'contrats_de_maintenance/index.html', {
        'page_title': 'Contrats de Maintenance',
        'description': 'Gestion et automatisation des contrats de maintenance récurrents.'
    })

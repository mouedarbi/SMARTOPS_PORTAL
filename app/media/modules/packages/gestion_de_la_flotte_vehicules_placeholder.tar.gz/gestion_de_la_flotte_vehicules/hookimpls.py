import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Flotte Véhicules",
            "url": "/app/gestion_de_la_flotte_vehicules/",
            "icon": "la-car"
        }]

plugin_implementation = PlaceholderPlugin()

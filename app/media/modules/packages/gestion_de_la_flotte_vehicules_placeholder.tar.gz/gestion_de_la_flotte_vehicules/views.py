from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'gestion_de_la_flotte_vehicules/index.html', {
        'page_title': 'Gestion de la Flotte Véhicules',
        'description': 'Suivi et attribution de la flotte de véhicules de maintenance.'
    })

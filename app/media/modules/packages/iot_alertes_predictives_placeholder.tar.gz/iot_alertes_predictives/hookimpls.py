import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class PlaceholderPlugin:
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "IoT & Alertes",
            "url": "/app/iot_alertes_predictives/",
            "icon": "la-broadcast-tower"
        }]

plugin_implementation = PlaceholderPlugin()

from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'iot_alertes_predictives/index.html', {
        'page_title': 'IoT & Alertes Prédictives',
        'description': 'Surveillance par capteurs connectés et génération d'alertes.'
    })

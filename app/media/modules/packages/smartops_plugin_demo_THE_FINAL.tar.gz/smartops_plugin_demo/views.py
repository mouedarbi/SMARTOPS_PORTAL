from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def index_view(request):
    return render(request, 'smartops_plugin_demo/index.html', {'page_title': 'Module Premium'})

import pluggy
hookimpl = pluggy.HookimplMarker("smartops")

class DemoPlugin:
    """
    TRACE_ID: SMARTOPS-DEMO-V1-FULL-LINKS-2026
    """
    @hookimpl
    def register_menu_items(self):
        return [{
            "label": "Module de Démo",
            "url": "/app/smartops_plugin_demo/",
            "icon": "la-gem"
        }]

plugin_implementation = DemoPlugin()
